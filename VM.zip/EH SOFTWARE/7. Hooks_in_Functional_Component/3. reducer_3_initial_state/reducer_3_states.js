import { useReducer } from "react";
const initialState = "Hello";
const reducer = (state, action) => {
  switch (action) {
    case "welcome":
      return "Welcome";

    case "goodbye":
      return "Good Bye";

    case "reset":
      return initialState;

    default:
      throw new Error("Error");
  }
};

const TextChange = () => {
  const [text, dispatch] = useReducer(reducer, initialState);

  return (
    <div>
      <h2>{text}</h2>

      <button onClick={() => dispatch("welcome")}>
        Welcome
      </button>

      <button onClick={() => dispatch("goodbye")}>
        Good Bye
      </button>

      <button onClick={() => dispatch("reset")}>
        Reset
      </button>
    </div>
  );
};

export default TextChange;
