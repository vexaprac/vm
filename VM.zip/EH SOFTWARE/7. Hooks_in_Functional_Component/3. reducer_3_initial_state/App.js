import './App.css';
import TextChange from './reducer_3_states.js';
import Person from './reducer_3_states.js';
function App() {
  return (
    <div className='App'>
      <TextChange/>
    </div>
  );
}
export default App;
