import React from "react";

export function Car(props){
    return (
        <>
        <h2>Car name : {props.carName}</h2>
        <h2>Car Color : {props.carColor}</h2>
        </>
    );
};

export function Product(props) {
    return (
        <div>
            <h1>{props.details}</h1>
            <Car carName='Tesla' carColor="Red"/>
        </div>
    );
};
