import React from "react";
import { Car, Product } from "./component/Functional_prop";
function App() {
    return (
        <div className = "App">
            <Product details = "Car Details"/>
        </div>
    );
}

export default App;

