import React,{ useState} from "react"; 
function AddRemoveArr(){
    const[users,setUsers]=useState([
        {id: 1, username: "User 1"}, 
        {id: 2, username: "User 2"} 
    ]);
    const addUser=()=>{ 
        const newUser={
             id: `${users.length+1}`,
             username: `User ${users.length+1}` 
            };
            const newUsers=[...users,newUser]; 
            console.log(newUsers);
            setUsers(newUsers); 
        };
        const removeUser=(index)=>()=>{ 
            const newUsers=[...users]; 
            console.log(newUsers); 
            newUsers.splice(index,1);
            setUsers(newUsers);
         }; 
            const addAfter=(index)=>()=>{
                const newUser={ 
                    id: `${users.length+1}`,
                     username: `User ${users.length+1}`
                     };
                     const newUsers=[...users];
                     newUsers.splice(index+1,0,newUser) 
                     console.log(newUsers)
                     setUsers(newUsers); 
                    };
                    return( 
                    <> 
                    <button onClick={addUser}>Add User</button>
                    {users.map((user,index)=>( 
                        <div className="users" key={user.id}>
                            {user.username} 
                            <button onClick={removeUser(index)}>Remove User</button> 
                            <button onClick={addAfter(index)}>Add immediate next User</button> 
                            </div>
                            ))} 
                            </> 
                            ); 
                        } 
                        export default AddRemoveArr;
