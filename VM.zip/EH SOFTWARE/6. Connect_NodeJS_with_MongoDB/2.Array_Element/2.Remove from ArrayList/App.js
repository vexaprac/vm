import AddRemoveArr from './Remove.js'; 
import './App.css';
function App() {
  return (
    <div className="App">
      <AddRemoveArr/>
    </div>
  );
}
export default App;
