import './App.css';
import MultipleValuesArr from './Add.js';
function App() {
  return (
    <div className="App">
      <MultipleValuesArr/>
    </div>
  );
}
export default App;
// from package.json delete "type": "commonjs"
// from index.js delete strictMode and keep <App/>