import React, { useState } from "react";
function MultipleValuesArr() {
    const friendsArray = ["Earth", "Bright", "Jeff", "Mew"];
    const [friends, setFriends] = useState(friendsArray);
    const handleFunction = () => {
        const newFriend = document.getElementById("friend").value;
        setFriends([...friends, newFriend]);
    };
    return (
        <div>
            <h1>List</h1>
            <ul>
                {friends.map((friend, index) => (
                    <li key={index}>
                        {friend}
                    </li>
                ))}
            </ul>
            <input type="text"id="friend"placeholder="Enter friend name"/>
            <button onClick={handleFunction}>ADD VALUES</button>
        </div>
    );
}
export default MultipleValuesArr;
