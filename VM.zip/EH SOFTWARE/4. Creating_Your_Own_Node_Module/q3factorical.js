const readline = require('readline');
const EventEmitter = require('events');

const eventEmitter = new EventEmitter();

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Function to emit event
function handleInput(num) {
    eventEmitter.emit('factorialReady', num);
}

// Event Listener
eventEmitter.on('factorialReady', (num) => {
    let factorial = 1;

    for (let i = 1; i <= num; i++) {
        factorial = factorial * i;
    }

    console.log("Factorial of " + num + " is: " + factorial);

    rl.close();
});

// Take input
rl.question("Enter a number: ", (input) => {
    handleInput(parseInt(input));
});