const readline = require('readline');
const EventEmitter = require('events');
const eventEmitter = new EventEmitter();
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
// Function to emit event
function handleInput(num) {
    eventEmitter.emit('fibonacciReady', num);
}
// Event Listener
eventEmitter.on('fibonacciReady', (num) => {
    let a = 0, b = 1;
    console.log("Fibonacci Series:");
    for (let i = 0; i < num; i++) {
        console.log(a);
        let next = a + b;
        a = b;
        b = next;
    }
    rl.close();
});
// Take input
rl.question("Enter the number of terms: ", (input) => {
    handleInput(parseInt(input));
});
