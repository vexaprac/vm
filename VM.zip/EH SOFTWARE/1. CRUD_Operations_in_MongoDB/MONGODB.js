
2) Create database with name "emp_db"
use emp_db
Write a query to create a collection:
db.createCollection("employee")
3) Query to insert single employee
db.employee.insertOne({
    employee_id: 101,
    name: "John Doe",
    department: "IT",
    Salary: 75000
})
4) Query to insert multiple employees
db.employee.insertMany([
    {
        employee_id: 102,
        name: "Jane Doe",
        department: "HR",
        Salary: 55000
    },
    {
        employee_id: 103,
        name: "Alex Roy",
        department: "Sales",
        Salary: 60000
    }
])
5) Query to add an array field — skills
db.employee.insertOne({
    employee_id: 104,
    name: "Priya Sharma",
    department: "Development",
    Salary: 75000,
    skills: ["MongoDB", "Node.js", "React.js"]
})

   Skills: MongoDB, Node, React
6) Query to insert nested object address
db.employee.insertOne({
    employee_id: 105,
    name: "Ravi Kumar",
    department: "Design",
    Salary: 50000,
    address: {
        street: "MG Road",
        city: "Pune",
        zipcode: 411001
    }
})
7) Display all the documents from the employee collection
db.employee.find()

8) Display employee who belongs to department IT
db.employee.find({ department: "IT" })

9) Employees with salary at 60000
db.employee.find({ Salary: { $gt: 60000 } })

10) Employee with Python skill
db.employee.find({ skills: "Python" })

11) Employee who lives in Pune city
db.employee.find({ "address.city": "Pune" })

12) Employee salary between 50000 to 80000
db.employee.find({
    Salary: { $gte: 50000, $lte: 80000 }
})

13) Employee whose department is either HR or Sales
db.employee.find({
    department: { $in: ["HR", "Sales"] }
})

14) Add a new skill "Express.js" to employee 101
db.employee.updateOne(
    { employee_id: 101 },
    { $push: { skills: "Express.js" } }
)

16) Add a skill "MongoDB" to an employee, but only if it doesn't exist
db.employee.updateOne(
    { employee_id: 101 },
    { $addToSet: { skills: "MongoDB" } }
)

17) Display the fields emp_id, name, department, Salary for all documents in collection employee
db.employee.find(
    {},
    {
        employee_id: 1,
        name: 1,
        department: 1,
        Salary: 1
    }
)

18) Display only emp_id, name, dept, but exclude the field _id
db.employee.find(
    {},
    {
        employee_id: 1,
        name: 1,
        department: 1,
        _id: 0
    }
)

19) Display employee with salary 50,000
db.employee.find({ Salary: 50000 })

20) Query to set salary 50,000 for employee whose department is HR
db.employee.updateOne(
    { department: "HR" },
    { $set: { Salary: 50000 } }
)

21) Query to set salary 35,000 for employee ID greater than 103
db.employee.updateMany(
    { employee_id: { $gt: 103 } },
    { $set: { Salary: 35000 } }
)
22) Query to remove the record of any one employee
db.employee.deleteOne({
    employee_id: 101
})
23) Query to rename employee collection as employee_details
db.employee.renameCollection("employee_details")

show collections