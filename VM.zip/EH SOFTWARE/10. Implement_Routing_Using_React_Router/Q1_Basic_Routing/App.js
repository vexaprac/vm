import React from 'react';
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";//npm install react-router-dom@6
import Home from "./Home";
import Contact from "./Contact";
import About from "./About";

function App() {
    return (
        <BrowserRouter>
            <nav>
                <Link to="/">Home</Link> | {" "}
                <Link to="/about">About</Link> | {" "}
                <Link to="/contact">Contact</Link>
            </nav>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/about" element={<About />} />
                <Route path="/contact" element={<Contact />} />
            </Routes>
        </BrowserRouter>
    );
}

export default App;

/* if already install react-router-dom paths: C:\awt\myapp>
rmdir /s /q node_modules
del package-lock.json
npm install
npm install react-router-dom@6
npm start
*/