import random

deck = [
    rank + suit
    for suit in ['spades', 'clubs', 'diamonds', 'hearts']
    for rank in ['A','1','2','3','4','5','6','7','8','9','10','J','Q','K']
]

random.shuffle(deck)
n = int(input("How many cards do you want to draw? "))

if n <= len(deck):
    for i in range(n):
        print(deck[i])
else:
    print("Not enough cards in the deck!")
