# Initial State
left_m = 0
left_c = 0
right_m = 3
right_c = 3
boat = "right"

# Function to display current state
def show():
    print("\nLeft Side : M =", left_m, " C =", left_c)
    print("Right Side : M =", right_m, " C =", right_c)
    print("Boat is on", boat)

# Function to check if missionaries are safe
def safe():
    if right_m > 0 and right_c > right_m:
        return False
    if left_m > 0 and left_c > left_m:
        return False
    return True

# Game Loop
while True:
    show()

    # Win Condition
    if left_m == 3 and left_c == 3:
        print("\nYou Won!")
        break

    m = int(input("Missionaries to move: "))
    c = int(input("Cannibals to move: "))

    # Boat capacity
    if m + c == 0 or m + c > 2:
        print("Boat can carry only 1 or 2 people.")
        continue

    # Save old values
    old_left_m = left_m
    old_left_c = left_c
    old_right_m = right_m
    old_right_c = right_c
    old_boat = boat

    # Move from left to right
    if boat == "left":
        if m > left_m or c > left_c:
            print("Not enough people.")
            continue
        left_m -= m
        left_c -= c
        right_m += m
        right_c += c
        boat = "right"

    # Move from right to left
    else:
        if m > right_m or c > right_c:
            print("Not enough people.")
            continue
        right_m -= m
        right_c -= c
        left_m += m
        left_c += c
        boat = "left"

    # Check safety
    if not safe():
        print("Invalid Move! Missionaries get eaten.")
        # Undo move
        left_m = old_left_m
        left_c = old_left_c
        right_m = old_right_m
        right_c = old_right_c
        boat = old_boat
