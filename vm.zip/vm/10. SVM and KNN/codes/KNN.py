from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
import seaborn as sn
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt

df = load_iris()
print(df)
print(df.feature_names)

X = df['data']
y = df['target']

print("X train", X)
print("y", y)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

knn = KNeighborsClassifier(n_neighbors=10)
train = knn.fit(X_train, y_train)

print('Target Names are : ', df.target_names)
print('Size of the test data : ', len(X_test))
print('X values of Test : ', X_test)
print('Y values of Test Data : ', y_test)

print('Predict classes for the above testing Data :')
y_pred = train.predict(X_test)
print('P values of Test data', y_pred)

print('Accuracy of the model :')
print(knn.score(X_test, y_test))

print("Confusion matrix of model")
cm = confusion_matrix(y_test, y_pred)
print(cm)

plt.figure(figsize=(7,5))
sn.heatmap(cm, annot=True)
plt.xlabel('Predicted')
plt.ylabel('Truth')
plt.show()
