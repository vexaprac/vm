from sklearn import svm
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
import seaborn as sn
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
from sklearn import metrics

df = load_iris()
print(df)
X = df['data']
y = df['target']

print("Feature name : ", df.feature_names)
print("Labels: ", df.target_names)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

classifier = svm.SVC(kernel='linear')
print('X train : ', X_train)
print('Y train: ', y_train)
classifier.fit(X_train, y_train)

print('Test Data : ', X_test)
y_pred = classifier.predict(X_test)
print('Accuracy : ', metrics.accuracy_score(y_test, y_pred))

iris = load_iris()
X = iris.data[:, :2]
y = iris.target

plt.scatter(X[:,0], X[:,1], c=y, cmap=plt.cm.coolwarm)
plt.xlabel('Sepal Length')
plt.ylabel('Sepal width')
plt.title('Sepal Width & Length')
plt.show()
