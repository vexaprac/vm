import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB

df = pd.read_csv("customer_profiles.csv")
target_col = "output"

X = df.drop(columns=[target_col])
y = df[target_col]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=1
)

print(df)
print("X_train data :", X_train)
print("X_test data :", X_test)
print("Y_train data :", y_train)
print("Y_test data :", y_test)

NB = GaussianNB()
NB = NB.fit(X_train, y_train)
y_pred = NB.predict(X_test)

print("ytest =", X_test)
print("ypred =", y_pred)
print("Accuracy :", metrics.accuracy_score(y_test, y_pred))

cm = metrics.confusion_matrix(y_test, y_pred)
print("Confusion Matrix :", cm)

plt.figure(figsize=(6, 4.5))
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=["Class 0", "Class 1"],
    yticklabels=["Class 0", "Class 1"],
)

plt.title(
    f"Gaussian Naive Bayes Confusion Matrix\n"
    f"Accuracy: {metrics.accuracy_score(y_test, y_pred) * 100:.1f}%"
)
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.tight_layout()
plt.show()
