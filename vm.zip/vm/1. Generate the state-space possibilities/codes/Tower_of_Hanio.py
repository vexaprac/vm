def tower_of_hanio(n, a, b, c):
    if n == 1:
        print(f"Move disk 1 from {a} to {c}")
        return

    tower_of_hanio(n - 1, a, c, b)
    print(f"Move disk {n} from {a} to {c}")
    tower_of_hanio(n - 1, b, a, c)

num_disks = 3
tower_of_hanio(num_disks, 'A', 'B', 'C')
