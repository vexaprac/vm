from collections import deque

def is_visited(state, visited):
    return state in visited

def water_jug_bfs():
    max_a, max_b = 5, 4
    visited = set()
    queue = deque()

    queue.append((0, 0))

    while queue:
        a, b = queue.popleft()

        if (a, b) in visited:
            continue

        visited.add((a, b))

        print(f"Jug A: {a}L, Jug B: {b}L")

        if a == 2 or b == 2:
            print("Found a solution!")
            return

        possible_states = [
            (max_a, b),  # Fill Jug A
            (a, max_b),  # Fill Jug B
            (0, b),      # Empty Jug A
            (a, 0),      # Empty Jug B

            # Pour Jug B into Jug A
            (min(a + b, max_a), b - (min(a + b, max_a) - a)),

            # Pour Jug A into Jug B
            (a - (min(a + b, max_b) - b), min(a + b, max_b))
        ]

        for state in possible_states:
            if state not in visited:
                queue.append(state)

    print("No solution found")

water_jug_bfs()
