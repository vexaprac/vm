graph : dict = {
    "A" : ({"D":1},3),
    "S" : ({"A":2 , "D":1 , "E":3},6),
    "D":({"G":2,"B":3},4),
    "B":({"C":2},2),
    "C":({"G":3},2),
    "E":({"G":2},5),
    "G":({},0)
}

def get_min(q):
    mn = (0,(0,float("INF")))
    for i in q:
        if sum(q[i] )< sum(mn[1]):
            mn = (i , q[i])
    return mn[0]

def a_star(graph , prev , dst , path ,pcost ,  q):
    print("Connected  nodes of current node " , prev , "with h(n) values")
    for n in graph[prev][0]:
        if n not in path:
            q[n] = (graph[n][1], graph[prev][0][n])
            print(n , "- >", q[n])
            add1 = sum(q[n])
            path_cost = pcost+add1
            print(f"A* value for {n} is {path_cost}")
    while q :
        mn =  get_min(q)
        
        print("Selecting minimum vertex  : " , mn )
        print("______________________________________________________")
        if dst == mn :
            return path + [dst]
        pc = pcost + q[mn][1]
        print("Previous path cost : " , pc)
        q.pop(mn)
        new_path = a_star(graph , mn , dest , path + [mn] ,pc , q) 
        if new_path:
            return new_path
    return []
        
source = input("Enter source vertex : ")
dest = input("Enter destination vertex : ")
heuristic = int(input("Enter the given heuristic value for source : "))
path = a_star(graph , source , dest , [] ,0,{source: (heuristic, 0)})

if path :
    print(path)

else:
    print("Path Not found !!")
