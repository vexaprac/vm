graph : dict = {
    "A" : ({"D":1},3),
    "S" : ({"A":2 , "D":1 , "E":3},6),
    "D":({"G":2,"B":3},4),
    "B":({"C":2},2),
    "C":({"G":3},2),
    "E":({"G":2},5),
    "G":({},0)
}

def greedy_search_rec(graph , prev , dst , path , q):
    print("Connected  nodes of current node " , prev , "with h(n) values")
    for n in graph[prev][0]:
        if n not in path:
            q[n] = graph[n][1]
            print(n , "- >", q[n])
    while q :
        mn =  min(q , key = q.get)
        q.pop(mn)
        print("Taking minimum h(n) vertex  : " , mn )
        if dst == mn :
            return path + [dst]
        new_path = greedy_search_rec(graph , mn , dst , path + [mn],q  )
        if new_path:
            return new_path
    return []

source = input("Enter source vertex : ")
dest = input("Enter destination vertex : ")
path = greedy_search_rec(graph , source , dest , [source] , {})

if path :
    print(path)

else:
    print("Path Not found !!")
